module.exports = {
    requirements: [{
            value: "biryani",
            label: "Biryani",
            image: "https://recipe30.com/wp-content/uploads/2023/03/chicken-Biryani.jpg"
        },
        {
            value: "noodles",
            label: "Noodles",
            image: "https://th.bing.com/th/id/OIP.5sD5fwYkYgyQHjIVBtndVQHaE7?w=280&h=186&c=7&r=0&o=5&pid=1.7"
        },
        {
            value: "fried-rice",
            label: "Fried-rice",
            image: "https://th.bing.com/th/id/OIP.ICy0mqubu5E5r5TcRHG1LAHaLH?w=184&h=276&c=7&r=0&o=5&pid=1.7"
        },
        {
            value: "chapati+curry",
            label: "Chapati + Curry",
            image: "https://w0.peakpx.com/wallpaper/392/129/HD-wallpaper-choling-vectors-stock-psd-north-indian-food-thumbnail.jpg"
        },
        {
            value: "bata-singaram",
            label: "Bata Singaram",
            image: "https://media-cdn.tripadvisor.com/media/photo-s/01/c7/83/47/mount-opera-star-resort.jpg"
        },
        {
            value: "abdullapurmet",
            label: "Abdullapurmet",
            image: "https://th.bing.com/th/id/OIP.jMMn-c4gts8jD6V7olNfDAHaDV?w=301&h=157&c=7&r=0&o=5&pid=1.7"
        },
        {
            value: "lbnagar",
            label: "L B Nagar",
            image: "https://www.siasat.com/wp-content/uploads/2022/03/LB-Nagar-Underpass.jpg"
        },
        {
            value: "pizza",
            label: "Pizza",
            image: "https://th.bing.com/th/id/OIP.kOC4SVEtjR50s0-RBs5vWwHaFX?rs=1&pid=ImgDetMain"
        },
        {
            value: "burger",
            label: "Burger",
            image: "https://i0.wp.com/thenutritionadventure.com/wp-content/uploads/2017/07/PourHouseAmericanBurger.jpg?resize=5236%2C3490"
        },
        {
            value: "cake",
            label: "Cake",
            image: "https://th.bing.com/th/id/OIP._lWcxVUUTlCh0mTyiHTCWAHaLI?rs=1&pid=ImgDetMain"
        },
        {
            value: "fullmeals",
            label: "Full meals",
            image: "https://i.redd.it/f69km2tizqx11.jpg"
        },
        {
            value: "bananas",
            label: "Bananas",
            image: "https://th.bing.com/th/id/OIP.CouZVPKhcW8z6scDVkw7YgHaEK?rs=1&pid=ImgDetMain"
        }
    ]

}