const controllers = module.exports;

controllers.api = require('./api');
controllers.pages = require('./pages');